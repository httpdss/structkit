# This file is maintained only for backwards compatibility.
# Configuration is now in pyproject.toml (PEP 517/518).
from setuptools import setup

setup()
